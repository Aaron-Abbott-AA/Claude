R18-T v1 audit checks were not in the handoff bundle (only the audit report); see the origin session.
