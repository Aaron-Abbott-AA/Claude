# Exact (Fraction) evaluation of the twisted-slope cover count of NOTE_TWIST_CONSTANCY.md, Theorem 3.4.
# Normalisation as in R16/R17/R18: q=E*h, h=n*E, E=r*Q*S, rho=Q/2, X=E/(2r), T=Q*S,
# M<16h/625 (N<M, a<M'<8h/625), d<=E+2, d_def<=q/1000.
# Cover (Thm 3.4):  N_good <= N d + 2deg[T]/qq + (1.5d^2+3.5d+1) + (D+2)(E+1)d + 4 a d + 2(D-1)(E-2)d
#                         + Q deg[T] (Q-1+T-D)/(Q-1) + 6 d_def + 7,     qq = osculation 2^a >= 128.
# We write deg[T] = theta * r*h and compute theta_max: the largest theta with count < 1551 q/4000.
# We compare with the a-priori range deg[T] <= e_M + d <= N d/rho + d (R18 Sec. 5) -> theta_up.
from fractions import Fraction as F
B = F(1551, 4000)

def Dof(Q, S):
    D = S
    while D >= Q: D //= Q
    return D

def rest(r, Q, S, n):
    E = r*Q*S; h = n*E; q = E*h; d = E+2
    D = Dof(Q, S)
    N = F(16*h, 625); a = F(8*h, 625)
    tot = N*d + F(3, 2)*d*d + F(7, 2)*d + 1 + (D+2)*(E+1)*d + 4*a*d + 2*(D-1)*(E-2)*d + 7
    return tot/q + F(6, 1000), D, E, h, q

def theta_max(r, Q, S, n, qq=128):
    R, D, E, h, q = rest(r, Q, S, n)
    T = Q*S
    coef = F(Q*(Q-1+T-D), Q-1) + F(2, qq)          # coefficient of deg[T]
    slack = B - R
    return slack*q/(coef*r*h), D, R

def theta_up(r, Q, S, n):
    E = r*Q*S; h = n*E; d = E+2; rho = F(Q, 2)
    N = F(16*h, 625)
    return (N*d/rho + d)/(r*h)

print("Theorem 3.4 closure window: deg[T] <= theta_max * r*h closes; a-priori deg[T] <= theta_up * r*h")
print(" r    Q    S     n   D  | rest(q) | theta_max | theta_up | ratio up/max")
rows = []
for r in [4, 8, 16]:
    for Q in [128, 256, 512, 1024]:
        for S in [64, 128, 256, 512, 1024, 2048, 4096]:
            for n in [256, 512, 1024, 2048, 4096]:
                if not (n < 4*Q): continue
                tm, D, R = theta_max(r, Q, S, n)
                if D < 4: continue
                tu = theta_up(r, Q, S, n)
                rows.append((r, Q, S, n, D, R, tm, tu))
for (r, Q, S, n, D, R, tm, tu) in rows:
    if r == 4 and n in (256, 1024) and S in (64, 512, 1024, 4096):
        print(f"{r:2d} {Q:5d} {S:5d} {n:5d} {D:4d} | {float(R):.4f} | {float(tm):9.4f} | {float(tu):8.3f} | {float(tu/tm) if tm>0 else float('inf'):8.2f}")
pos = [x for x in rows if x[6] > 0]
print("cases with D>=4:", len(rows), " closing window nonempty (theta_max>0):", len(pos))
print("min theta_max over cases with D<=n/64 :", float(min(x[6] for x in rows if x[4]*64 <= x[3])))
print("cases where window covers whole a-priori range (theta_max>=theta_up):", sum(1 for x in rows if x[6] >= x[7]))
# D thresholds: largest D (power of 2, >=4) with theta_max>0, worst r=4, Q=128, S=Q*D (or S=D if D>=64,<Q)
def theta_D(D, n, r=4, Q=None):
    if Q is None:
        Q = 128
        while 4*Q <= n: Q *= 2          # least strip-admissible Q
    S = D if 64 <= D < Q else Q*D
    assert Dof(Q, S) == D
    return theta_max(r, Q, S, n)[0]
for n in [256, 512, 1024, 2048, 4096, 8192]:
    ok = [D for D in [4, 8, 16, 32, 64] if theta_D(D, n) > 0]
    print(f"n={n}: D in {{4..64}} with nonempty window (r=4, least admissible Q): {ok};  theta_max(D=4) = {float(theta_D(4, n)):.4f}")
# exact worst value of the deg[T]-free part at the canonical corner r=4,Q=128,S=512 (D=4), n=256
R, D, E, h, q = rest(4, 128, 512, 256)
print("corner r=4,Q=128,S=512,n=256: D=", D, " rest =", R, "=", float(R), " theta_max =", float(theta_max(4, 128, 512, 256)[0]))

# K-case (Prop 4.3): excluded when 2a < d'. With d'>=2E-2, a = M'+X-rho-d' : sufficient M < 6E - T + Q - 5.
print("K-case closes for M < 6E - T + Q - 5; strip has M up to 16h/625 >= 16*256E/625 = %.3f E" % (16*256/625))
