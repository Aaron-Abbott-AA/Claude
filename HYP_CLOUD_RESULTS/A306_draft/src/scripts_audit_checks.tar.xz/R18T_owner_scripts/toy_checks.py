# COMPUTED illustrations for NOTE_TWIST_CONSTANCY.md (exact arithmetic in GF(2^16); random evaluation).
# (1) [f^[X]]_x = k0^X J^[X] Omega J^[X,t]  (Lemma 2.1), random paired centre e = LU x NU, f = L^tY x N^tY.
# (2) FNAO slope form with A=(T^t)^[rho] and c=(1,s^rho) equals F(s)^rho, F = T22 s^{Q+1}+T21 s^Q+T12 s+T11 (Lemma 1.2).
# (3) reduced second-layer polynomial P_D^B(c,Y)=(K c^[D])^t C_c(Y) (B c) on a line is nonzero for random
#     generically invertible C-pencils and D=4,8 (Lemma 3.2 algebra); FNAP's D=1,2 counterexamples vanish.
# (4) the K-case is formally nonempty: C_P=p (x) b1perp + F N_P, C_R=p (x) b2perp + F N_R with b_i rho*qq-th
#     powers of linear forms gives C_c(Z) B c = 0 on {F=0} for all c, and det(v1 C_P+v2 C_R) != 0 (Example 4.4).
import itertools, random
import numpy as np
import galois
GF = galois.GF(2**16)
random.seed(7); np.random.seed(7)
def R(): return GF(random.randrange(1, 2**16))
def cross(a, b): return GF([a[1]*b[2]+a[2]*b[1], a[2]*b[0]+a[0]*b[2], a[0]*b[1]+a[1]*b[0]])
def frob(v, k): return v**k
ok = True
# (1)
L = GF(np.random.randint(0, 2**16, (3, 3))); N = GF(np.random.randint(0, 2**16, (3, 3)))
for X in [2, 4, 8]:
    for _ in range(5):
        Y = GF(np.random.randint(0, 2**16, 3)); v = GF(np.random.randint(0, 2**16, 3))
        j1 = L.T @ Y; j2 = N.T @ Y; f = cross(j1, j2)
        lhs = cross(frob(f, X), v)
        J = np.stack([frob(j1, X), frob(j2, X)], axis=1)          # 3x2
        Om = GF([[0, 1], [1, 0]])
        rhs = J @ (Om @ (J.T @ v))
        ok &= bool(np.all(lhs == rhs))
# e(f(Y)) prop Y check (f = J-minors is the inverse up to scalar)
U = GF(np.random.randint(0, 2**16, 3)); e = cross(L @ U, N @ U)
fe = cross(L.T @ e, N.T @ e)
print("(1) cross-product identity for X=2,4,8:", ok, "; f(e(U)) parallel U:", bool(np.all(cross(fe, U) == 0)))
# (2)
ok2 = True
for rho in [2, 4, 8]:
    Q = 2*rho
    for _ in range(5):
        T = GF(np.random.randint(1, 2**16, (2, 2))); s = R()
        A = (T.T)**rho
        c = GF([1, s**rho])
        val = c @ A @ c**Q
        Fs = T[1, 1]*s**(Q+1) + T[1, 0]*s**Q + T[0, 1]*s + T[0, 0]
        ok2 &= bool(val == Fs**rho)
print("(2) c^t A c^[Q] = F(s)^rho for rho=2,4,8:", ok2)
# (3)
a = 3
monos = [m for m in itertools.product(range(a+1), repeat=3) if sum(m) == a]
def rpoly(deg=None):
    ms = monos if deg is None else [m for m in itertools.product(range(deg+1), repeat=3) if sum(m) == deg]
    return {m: R() for m in ms}
def ev(p, Y): return sum((cf*Y[0]**m[0]*Y[1]**m[1]*Y[2]**m[2] for m, cf in p.items()), GF(0))
def rmat(deg=None): return [[rpoly(deg), rpoly(deg)], [rpoly(deg), rpoly(deg)]]
def evm(Cm, Y): return GF([[ev(Cm[i][j], Y) for j in range(2)] for i in range(2)])
def Kmat(B, Q, j, D):
    Bi = B.copy()
    for _ in range(j): Bi = (Bi**Q) @ B          # B_{i+1} = B_i^[Q] B
    return Bi**D
def PD(CP, CR, B, Q, j, D, c, Y):
    Kc = Kmat(B, Q, j, D) @ (c**D)
    Cc = c[0]*evm(CP, Y) + c[1]*evm(CR, Y)
    return Kc @ Cc @ (B @ c)
nz = 0; trials = 0
for D in [4, 8]:
    for Q in [4, 8]:
        for j in [0, 1]:
            CP, CR = rmat(), rmat(); B = GF(np.random.randint(1, 2**16, (2, 2)))
            Y0 = GF(np.random.randint(0, 2**16, 3)); Y1 = GF(np.random.randint(0, 2**16, 3))
            vals = [PD(CP, CR, B, Q, j, D, GF([R(), R()]), Y0 + R()*Y1) for _ in range(4)]
            trials += 1; nz += any(v != 0 for v in vals)
print(f"(3) reduced P_D on a random line nonzero in {nz}/{trials} random generically invertible pencils (D=4,8)")
# FNAP counterexamples, D=1,2 (already in reduced z-form: z^[D,t] C(z) z)
z = lambda: GF([R(), R()])
van = True
for _ in range(10):
    zz = z(); C1 = zz[0]*GF([[0, 1], [1, 0]]); van &= bool(zz @ C1 @ zz == 0)
    C2 = GF([[0, zz[1]], [zz[0], 0]]); van &= bool((zz**2) @ C2 @ zz == 0)
print("(3') FNAP D=1,2 counterexamples vanish identically:", van)
# (4) K-case formal example on the conic F = Y0*Y2 + Y1^2 (param (1,t,t^2)), N = rho*qq = 8
Nn = 8
al1, be1, al2, be2 = [GF(np.random.randint(0, 2**16, 3)) for _ in range(4)]
p = [rpoly(1), rpoly(1)]   # deg p = 1, deg b_perp = 8: entries homogeneous of degree a = 9
NP, NR = rmat(7), rmat(7)  # F*N has degree 2+7 = 9
def Fc(Y): return Y[0]*Y[2] + Y[1]**2
def b1(Y): return GF([(be1 @ Y)**Nn, (al1 @ Y)**Nn])
def b2(Y): return GF([(be2 @ Y)**Nn, (al2 @ Y)**Nn])
def CPm(Y):
    x, y = b1(Y); pv = GF([ev(p[0], Y), ev(p[1], Y)])
    return np.outer(pv, GF([y, x])) + Fc(Y)*evm(NP, Y)
def CRm(Y):
    x, y = b2(Y); pv = GF([ev(p[0], Y), ev(p[1], Y)])
    return np.outer(pv, GF([y, x])) + Fc(Y)*evm(NR, Y)
okK = True
for _ in range(6):
    t = R(); Z = GF([1, t, t*t])                  # point of {F=0}
    Bm = np.stack([b1(Z), b2(Z)], axis=1)
    for _ in range(3):
        c = GF([R(), R()])
        okK &= bool(np.all((c[0]*CPm(Z) + c[1]*CRm(Z)) @ (Bm @ c) == 0))
Yg = GF(np.random.randint(0, 2**16, 3)); v = GF([R(), R()])
M2 = v[0]*CPm(Yg) + v[1]*CRm(Yg)
detg = M2[0, 0]*M2[1, 1] + M2[0, 1]*M2[1, 0]
print("(4) K-case example: C_c(Z)Bc=0 on F=0 for all tested c:", okK, "; det pencil at a generic Y nonzero:", bool(detg != 0))
